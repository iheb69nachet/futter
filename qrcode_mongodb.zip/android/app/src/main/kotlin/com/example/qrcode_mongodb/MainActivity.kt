package com.example.qrcode_mongodb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
